const appContainer = document.getElementById('app-container');

export function renderView(htmlContent, callback = null) {
    if (!appContainer) {
        console.error('El contenedor de la aplicación (#app-container) no fue encontrado.');
        return;
    }

    appContainer.innerHTML = '';

    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = htmlContent;

    while (tempDiv.firstChild) {
        appContainer.appendChild(tempDiv.firstChild);
    }

    if (callback && typeof callback === 'function') {
        callback();
    }
}

export function showMessage(message, type = 'info', duration = 3000) {
    const messageContainer = document.createElement('div');
    messageContainer.className = `alert alert-${type} alert-dismissible fade show w-100 mb-3 text-center`; // Bootstrap classes
    messageContainer.setAttribute('role', 'alert');
    messageContainer.innerHTML = `
        <span>${message}</span>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;

    if (appContainer.firstChild) {
        appContainer.insertBefore(messageContainer, appContainer.firstChild);
    } else {
        appContainer.appendChild(messageContainer);
    }

    setTimeout(() => {
        const bsAlert = new bootstrap.Alert(messageContainer);
        bsAlert.close();
    }, duration);
}