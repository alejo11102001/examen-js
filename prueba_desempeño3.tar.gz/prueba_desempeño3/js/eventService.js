const EVENTS_API_BASE_URL = 'http://localhost:3000/events';
const USERS_API_BASE_URL = 'http://localhost:3000/users'; 



export async function getEvents() {
    try {
        const response = await fetch(EVENTS_API_BASE_URL);
        if (!response.ok) {
            throw new Error(`Error al obtener eventos: ${response.statusText}`);
        }
        return await response.json();
    } catch (error) {
        console.error('Error en getEvents:', error);
        throw error;
    }
}

export async function getEventById(eventId) {
    try {
        const response = await fetch(`${EVENTS_API_BASE_URL}/${eventId}`);
        if (!response.ok) {
            if (response.status === 404) {
                throw new Error('Evento no encontrado.');
            }
            throw new Error(`Error al obtener el evento: ${response.statusText}`);
        }
        return await response.json();
    } catch (error) {
        console.error('Error en getEventById:', error);
        throw error;
    }
}

export async function createEvent(eventData) {
    try {
        const response = await fetch(EVENTS_API_BASE_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ ...eventData, registeredAttendees: [] }),
        });
        if (!response.ok) {
            throw new Error(`Error al crear el evento: ${response.statusText}`);
        }
        return await response.json();
    } catch (error) {
        console.error('Error en createEvent:', error);
        throw error;
    }
}

export async function updateEvent(eventId, updatedData) {
    try {
        const response = await fetch(`${EVENTS_API_BASE_URL}/${eventId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(updatedData),
        });
        if (!response.ok) {
            throw new Error(`Error al actualizar el evento: ${response.statusText}`);
        }
        return await response.json();
    } catch (error) {
        console.error('Error en updateEvent:', error);
        throw error;
    }
}

export async function deleteEvent(eventId) {
    try {
        const response = await fetch(`${EVENTS_API_BASE_URL}/${eventId}`, {
            method: 'DELETE',
        });
        if (!response.ok) {
            throw new Error(`Error al eliminar el evento: ${response.statusText}`);
        }
    } catch (error) {
        console.error('Error en deleteEvent:', error);
        throw error;
    }
}

export async function registerAttendee(eventId, user) {
    try {
        const event = await getEventById(eventId);
        if (!event) {
            throw new Error('Evento no encontrado.');
        }

        if (event.registeredAttendees.length >= event.capacity) {
            throw new Error('El evento ha alcanzado su capacidad máxima.');
        }

        if (event.registeredAttendees.some(attendee => attendee.id === user.id)) {
            throw new Error('Ya estás registrado en este evento.');
        }

        const updatedAttendees = [...event.registeredAttendees, { id: user.id, email: user.email }];
        const updatedEvent = { ...event, registeredAttendees: updatedAttendees };

        const response = await fetch(`${EVENTS_API_BASE_URL}/${eventId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(updatedEvent),
        });

        if (!response.ok) {
            throw new Error(`Error al registrar asistente en el evento: ${response.statusText}`);
        }

        const updatedEventResult = await response.json();

        const userResponse = await fetch(`${USERS_API_BASE_URL}/${user.id}`);
        if (!userResponse.ok) {
            console.warn('No se pudo obtener el usuario para actualizar sus eventos registrados.');
            return updatedEventResult;
        }
        const currentUserData = await userResponse.json();

        const updatedUserEvents = currentUserData.registeredEvents ? [...currentUserData.registeredEvents] : [];
        if (!updatedUserEvents.some(e => e.id === event.id)) {
            updatedUserEvents.push({ id: event.id, name: event.name, date: event.date });
        }

        await fetch(`${USERS_API_BASE_URL}/${user.id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ ...currentUserData, registeredEvents: updatedUserEvents }),
        });

        return updatedEventResult;

    } catch (error) {
        console.error('Error en registerAttendee:', error);
        throw error;
    }
}

export async function unregisterAttendee(eventId, user) {
    try {
        const event = await getEventById(eventId);
        if (!event) {
            throw new Error('Evento no encontrado.');
        }

        const isRegistered = event.registeredAttendees.some(attendee => attendee.id === user.id);
        if (!isRegistered) {
            throw new Error('No estás registrado en este evento.');
        }

        const updatedAttendees = event.registeredAttendees.filter(attendee => attendee.id !== user.id);
        const updatedEvent = { ...event, registeredAttendees: updatedAttendees };

        const response = await fetch(`${EVENTS_API_BASE_URL}/${eventId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(updatedEvent),
        });

        if (!response.ok) {
            throw new Error(`Error al cancelar el registro del asistente en el evento: ${response.statusText}`);
        }

        const updatedEventResult = await response.json();

        const userResponse = await fetch(`${USERS_API_BASE_URL}/${user.id}`);
        if (!userResponse.ok) {
            console.warn('No se pudo obtener el usuario para actualizar sus eventos registrados.');
            return updatedEventResult; 
        }
        const currentUserData = await userResponse.json();

        if (currentUserData.registeredEvents) {
            const updatedUserEvents = currentUserData.registeredEvents.filter(e => e.id !== event.id);
            await fetch(`${USERS_API_BASE_URL}/${user.id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ ...currentUserData, registeredEvents: updatedUserEvents }),
            });
        }

        return updatedEventResult;

    } catch (error) {
        console.error('Error en unregisterAttendee:', error);
        throw error;
    }
}