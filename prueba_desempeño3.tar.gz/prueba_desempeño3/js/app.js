import { isAuthenticated, getCurrentUser, logoutUser } from './auth.js';
import { navigateTo, setupRouter } from './router.js';

function updateNavbar() {
    const navLinksContainer = document.getElementById('nav-links');
    if (!navLinksContainer) {
        console.error('Contenedor de enlaces de navegación no encontrado.');
        return;
    }

    navLinksContainer.innerHTML = ''; 

    if (isAuthenticated()) {
        const currentUser = getCurrentUser();
        const userRole = currentUser ? currentUser.role : 'visitor'; 

        const dashboardLink = document.createElement('a');
        dashboardLink.href = '#dashboard';
        dashboardLink.className = 'btn btn-outline-info me-2 btn_dash';
        dashboardLink.textContent = 'Dashboard';
        dashboardLink.addEventListener('click', (e) => {
            e.preventDefault();
            navigateTo('/dashboard');
        });
        navLinksContainer.appendChild(dashboardLink);

        if (userRole === 'admin') {
            const createEventLink = document.createElement('a');
            createEventLink.href = '#dashboard/events/create';
            createEventLink.className = 'btn btn-outline-success me-2 btn_create';
            createEventLink.textContent = 'Crear Evento';
            createEventLink.addEventListener('click', (e) => {
                e.preventDefault();
                navigateTo('/dashboard/events/create');
            });
            navLinksContainer.appendChild(createEventLink);
        }

        const logoutButton = document.createElement('button');
        logoutButton.className = 'btn btn-danger btn_out'; 
        logoutButton.textContent = 'Cerrar Sesión';
        logoutButton.addEventListener('click', () => {
            logoutUser();
            updateNavbar();
            navigateTo('/login');
        });
        navLinksContainer.appendChild(logoutButton);

        const userInfo = document.createElement('span');
        userInfo.className = 'text-black ms-3 d-none d-md-inline';
        userInfo.textContent = `Bienvenido, ${currentUser.email} (${userRole})`;
        navLinksContainer.appendChild(userInfo);

    } else {
        const loginLink = document.createElement('a');
        loginLink.href = '#login';
        loginLink.className = 'btn btn-outline-light me-2 btn-style';
        loginLink.textContent = 'Login';
        loginLink.addEventListener('click', (e) => {
            e.preventDefault();
            navigateTo('/login');
        });
        navLinksContainer.appendChild(loginLink);

        const registerLink = document.createElement('a');
        registerLink.href = '#register';
        registerLink.className = 'btn btn-primary btn-style';
        registerLink.textContent = 'Register';
        registerLink.addEventListener('click', (e) => {
            e.preventDefault();
            navigateTo('/register');
        });
        navLinksContainer.appendChild(registerLink);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    setupRouter(updateNavbar);
    updateNavbar();
    const initialPath = window.location.hash.substring(1) || (isAuthenticated() ? '/dashboard' : '/login');
    navigateTo(initialPath);
    window.addEventListener('hashchange', () => {
        const path = window.location.hash.substring(1);
        navigateTo(path);
    });
});