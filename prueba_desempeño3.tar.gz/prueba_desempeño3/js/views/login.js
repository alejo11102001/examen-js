import { renderView, showMessage } from '../viewManager.js';
import { loginUser, isAuthenticated } from '../auth.js';
import { navigateTo } from '../router.js';

export function render() {
    if (isAuthenticated()) {
        navigateTo('/dashboard');
        return;
    }

    const htmlContent = `
        <div class="container my-4">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-5">
                    <div>
                        <h2 class="card-title text-center mb-4 fw-bold">Login</h2>
                        <form id="loginForm">
                            <div class="mb-3">
                                <label for="email" class="form-label fw-bold">Email:</label>
                                <input type="email" class="form-control" id="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label fw-bold">Password:</label>
                                <input type="password" class="form-control" id="password" required>
                            </div>
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary btn-lg btn-style">Login</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    `;

    renderView(htmlContent, attachEventListeners);
}

function attachEventListeners() {
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    const goToRegisterLink = document.getElementById('goToRegister');
    if (goToRegisterLink) {
        goToRegisterLink.addEventListener('click', (e) => {
            e.preventDefault();
            navigateTo('/register'); 
        });
    }

    const backToDashboardBtn = document.getElementById('backToDashboardBtn');
    if (backToDashboardBtn) {
        backToDashboardBtn.addEventListener('click', () => {
            navigateTo('/dashboard');
        });
    }
}

async function handleLogin(event) {
    event.preventDefault(); 

    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');

    const email = emailInput.value;
    const password = passwordInput.value;

    if (!email || !password) {
        showMessage('Por favor, ingresa tu email y contraseña.', 'warning');
        return;
    }

    try {
        await loginUser(email, password);
        showMessage('Inicio de sesión exitoso.', 'success');
        navigateTo('/dashboard');
    } catch (error) {
        console.error('Error al iniciar sesión:', error);
        showMessage(`Error al iniciar sesión: ${error.message}`, 'danger');
    }
}