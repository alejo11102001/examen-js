import { renderView, showMessage } from '../viewManager.js';
import { getEventById, updateEvent } from '../eventService.js';
import { navigateTo } from '../router.js';

export async function render(params) {
    const eventId = params.id;
    if (!eventId) {
        showMessage('ID de evento no proporcionado para la edición.', 'danger');
        navigateTo('/dashboard');
        return;
    }

    let event = null;
    try {
        event = await getEventById(eventId);
    } catch (error) {
        console.error('Error al cargar el evento para edición:', error);
        showMessage(`Error al cargar el evento: ${error.message}`, 'danger');
        navigateTo('/dashboard');
        return;
    }

    const htmlContent = `
        <div class="container my-4">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6">
                    <div class="card shadow-lg p-4">
                        <h2 class="card-title text-center mb-4 fw-bold">Editar Evento</h2>
                        <form id="editEventForm">
                            <input type="hidden" id="eventId" value="${event.id}">
                            <div class="mb-3">
                                <label for="eventName" class="form-label fw-bold">Nombre del Evento:</label>
                                <input type="text" class="form-control" id="eventName" value="${event.name}" required>
                            </div>
                            <div class="mb-3">
                                <label for="eventDate" class="form-label fw-bold">Fecha:</label>
                                <input type="date" class="form-control" id="eventDate" value="${event.date}" required>
                            </div>
                            <div class="mb-3">
                                <label for="eventDescription" class="form-label fw-bold">Descripción:</label>
                                <input type="text" class="form-control" id="eventDescription" value="${event.description}" required>
                            </div>
                            <div class="mb-3">
                                <label for="eventCapacity" class="form-label fw-bold">Capacidad:</label>
                                <input type="number" class="form-control" id="eventCapacity" value="${event.capacity}" min="1" required>
                            </div>
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary btn-lg btn-style">Guardar Cambios</button>
                                <button type="button" id="cancelEdit" class="btn btn-secondary btn-lg">Cancelar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    `;

    renderView(htmlContent, attachEventListeners);
}

function attachEventListeners() {
    const editEventForm = document.getElementById('editEventForm');
    if (editEventForm) {
        editEventForm.addEventListener('submit', handleEditEvent);
    }

    const cancelEditButton = document.getElementById('cancelEdit');
    if (cancelEditButton) {
        cancelEditButton.addEventListener('click', () => {
            navigateTo('/dashboard');
        });
    }
}

async function handleEditEvent(event) {
    event.preventDefault();

    const eventId = document.getElementById('eventId').value;
    const eventName = document.getElementById('eventName').value;
    const eventDate = document.getElementById('eventDate').value;
    const eventDescription = document.getElementById('eventDescription').value;
    const eventCapacity = parseInt(document.getElementById('eventCapacity').value, 10);

    if (!eventName || !eventDate || !eventDescription || isNaN(eventCapacity) || eventCapacity <= 0) {
        showMessage('Por favor, completa todos los campos correctamente.', 'warning');
        return;
    }

    const updatedData = {
        name: eventName,
        date: eventDate,
        description: eventDescription,
        capacity: eventCapacity
    };

    try {
        await updateEvent(eventId, updatedData);
        showMessage('Evento actualizado exitosamente.', 'success');
        navigateTo('/dashboard');
    } catch (error) {
        console.error('Error al actualizar el evento:', error);
        showMessage(`Error al actualizar el evento: ${error.message}`, 'danger');
    }
}       