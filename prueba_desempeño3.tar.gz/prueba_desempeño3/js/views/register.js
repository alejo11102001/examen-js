import { renderView, showMessage } from '../viewManager.js';
import { registerUser, isAuthenticated } from '../auth.js';
import { navigateTo } from '../router.js';


export function render() {
    if (isAuthenticated()) {
        navigateTo('/dashboard');
        return;
    }

    const htmlContent = `
        <div class="container my-4">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-5">
                    <div>
                        <h2 class="card-title text-center mb-4 fw-bold">Register</h2>
                        <form id="registerForm">
                            <div class="mb-3">
                                <label for="email" class="form-label fw-bold">Email:</label>
                                <input type="email" class="form-control" id="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label fw-bold">Password:</label>
                                <input type="password" class="form-control" id="password" required>
                            </div>
                            <div class="mb-3">
                                <label for="confirm-password" class="form-label fw-bold">Confirm password:</label>
                                <input type="password" class="form-control" id="confpassword" required>
                            </div>
                            <div class="mb-3">
                                <label for="role" class="form-label fw-bold">Rol:</label>
                                <select class="form-select" id="role" required>
                                    <option value="visitor" selected>Visitante</option>
                                    <option value="admin">Administrador</option>
                                </select>
                            </div>
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary btn-lg btn-style">Register</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    `;

    renderView(htmlContent, attachEventListeners);
}

function attachEventListeners() {
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }

    const goToLoginLink = document.getElementById('goToLogin');
    if (goToLoginLink) {
        goToLoginLink.addEventListener('click', (e) => {
            e.preventDefault();
            navigateTo('/login'); 
        });
    }
}

async function handleRegister(event) {
    event.preventDefault();

    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const confpasswordInput = document.getElementById('confpassword')
    const roleSelect = document.getElementById('role');

    const email = emailInput.value.trim();
    const password = passwordInput.value;
    const confpassword = confpasswordInput.value;
    const role = roleSelect.value;

    if (!email || !password || !confpassword || !role) {
        showMessage('Por favor, completa todos los campos.', 'warning');
        return;
    }

    if (password !== confpassword) {
        showMessage('Las contraseñas no coinciden.', 'danger');
        return;
    }

    try {
        await registerUser(email, password, role);
        showMessage('Registro exitoso. Ahora puedes iniciar sesión.', 'success');
        navigateTo('/login'); 
    } catch (error) {
        console.error('Error al registrar usuario:', error);
        showMessage(`Error al registrar: ${error.message}`, 'danger');
    }
}