import { renderView, showMessage } from '../viewManager.js';
import { createEvent } from '../eventService.js';
import { navigateTo } from '../router.js';

export function render() {
    const htmlContent = `
        <div class="container my-4">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6">
                    <div class="card shadow-lg p-4">
                        <h2 class="card-title text-center mb-4 fw-bold">Crear Nuevo Evento</h2>
                        <form id="createEventForm">
                            <div class="mb-3">
                                <label for="eventName" class="form-label fw-bold">Nombre del Evento:</label>
                                <input type="text" class="form-control" id="eventName" required>
                            </div>
                            <div class="mb-3">
                                <label for="eventDate" class="form-label fw-bold">Fecha:</label>
                                <input type="date" class="form-control" id="eventDate" required>
                            </div>
                            <div class="mb-3">
                                <label for="eventDescription" class="form-label fw-bold">Descripción:</label>
                                <input type="text" class="form-control" id="eventDescription" required>
                            </div>
                            <div class="mb-3">
                                <label for="eventCapacity" class="form-label fw-bold">Capacidad:</label>
                                <input type="number" class="form-control" id="eventCapacity" min="1" required>
                            </div>
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary btn-lg btn-style">Crear Evento</button>
                                <button type="button" id="cancelCreate" class="btn btn-secondary btn-lg">Cancelar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    `;

    renderView(htmlContent, attachEventListeners);
}

function attachEventListeners() {
    const createEventForm = document.getElementById('createEventForm');
    if (createEventForm) {
        createEventForm.addEventListener('submit', handleCreateEvent);
    }

    const cancelCreateButton = document.getElementById('cancelCreate');
    if (cancelCreateButton) {
        cancelCreateButton.addEventListener('click', () => {
            navigateTo('/dashboard'); // Redirigir al dashboard al cancelar
        });
    }
}

async function handleCreateEvent(event) {
    event.preventDefault();

    const eventName = document.getElementById('eventName').value;
    const eventDate = document.getElementById('eventDate').value;
    const eventDescription = document.getElementById('eventDescription').value;
    const eventCapacity = parseInt(document.getElementById('eventCapacity').value);

    if (!eventName || !eventDate || !eventDescription || isNaN(eventCapacity) || eventCapacity <= 0) {
        showMessage('Por favor, completa todos los campos correctamente.', 'warning');
        return;
    }

    const eventData = {
        name: eventName,
        date: eventDate,
        description: eventDescription,
        capacity: eventCapacity,
        registeredAttendees: []
    };

    try {
        await createEvent(eventData);
        showMessage('Evento creado exitosamente.', 'success');
        navigateTo('/dashboard');
    } catch (error) {
        console.error('Error al crear el evento:', error);
        showMessage(`Error al crear el evento: ${error.message}`, 'danger');
    }
}
       