import { renderView, showMessage } from '../viewManager.js';
import { getEvents, deleteEvent, registerAttendee, unregisterAttendee } from '../eventService.js';
import { isAuthenticated, getUserRole, getCurrentUser } from '../auth.js';
import { navigateTo } from '../router.js';

export async function render() {
    const userRole = getUserRole();
    const currentUser = getCurrentUser();
    let events = [];

    try {
        events = await getEvents();
    } catch (error) {
        console.error('Error al cargar eventos:', error);
        showMessage('Error al cargar los eventos. Inténtalo de nuevo más tarde.', 'danger');
        events = [];
    }

    const htmlContent = `

            ${events.length === 0 ? `
            ` : `
                <div class="table-responsive">
                    <table class="table table-striped table-hover align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th scope="col">Nombre</th>
                                <th scope="col">Fecha</th>
                                <th scope="col">Descripción</th>
                                <th scope="col">Capacidad</th>
                                <th scope="col">Asistentes</th>
                                <th scope="col">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${events.map(event => `
                                <tr>
                                    <td>${event.name}</td>
                                    <td>${event.date}</td>
                                    <td>${event.description}</td>
                                    <td>${event.capacity}</td>
                                    <td>
                                        ${event.registeredAttendees ? event.registeredAttendees.length : 0} / ${event.capacity}
                                        ${event.registeredAttendees && event.registeredAttendees.some(attendee => attendee.id === currentUser?.id) ?
                                            `<span class="badge bg-success ms-2">Registrado</span>` : ''
                                        }
                                    </td>
                                    <td>
                                        ${userRole === 'admin' ? `
                                            <button class="btn btn-warning btn-sm me-2 edit-event-btn" data-id="${event.id}">
                                                <i class="fas fa-edit"></i> Editar
                                            </button>
                                            <button class="btn btn-danger btn-sm delete-event-btn" data-id="${event.id}">
                                                <i class="fas fa-trash-alt"></i> Eliminar
                                            </button>
                                        ` : `
                                            ${event.registeredAttendees && event.registeredAttendees.some(attendee => attendee.id === currentUser?.id) ? `
                                                <button class="btn btn-danger btn-sm unregister-event-btn" data-id="${event.id}">
                                                    <i class="fas fa-times-circle"></i> Cancelar Registro
                                                </button>
                                            ` : `
                                                <button class="btn btn-primary btn-sm register-event-btn" data-id="${event.id}"
                                                    ${event.registeredAttendees && event.registeredAttendees.length >= event.capacity ? 'disabled' : ''}>
                                                    <i class="fas fa-user-plus"></i> Registrarse
                                                </button>
                                            `}
                                        `}
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            `}

            ${userRole === 'visitor' && currentUser && currentUser.registeredEvents && currentUser.registeredEvents.length > 0 ? `
                <h3 class="text-center my-4 text-secondary">Mis Registros</h3>
                <div class="table-responsive">
                    <table class="table table-striped table-hover align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th scope="col">Nombre del Evento</th>
                                <th scope="col">Fecha</th>
                                <th scope="col">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${events.filter(event => currentUser.registeredEvents.some(regEvent => regEvent.id === event.id)).map(event => `
                                <tr>
                                    <td>${event.name}</td>
                                    <td>${event.date}</td>
                                    <td>
                                        <button class="btn btn-danger btn-sm unregister-event-btn" data-id="${event.id}">
                                            <i class="fas fa-times-circle"></i> Cancelar Registro
                                        </button>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            ` : ''}
        </div>
    `;

    renderView(htmlContent, attachEventListeners);
}

function attachEventListeners() {
    const userRole = getUserRole();
    const currentUser = getCurrentUser();

    if (userRole === 'admin') {
        const createEventBtn = document.getElementById('createEventBtn');
        if (createEventBtn) {
            createEventBtn.addEventListener('click', () => {
                navigateTo('/dashboard/events/create');
            });
        }

        document.querySelectorAll('.edit-event-btn').forEach(button => {
            button.addEventListener('click', (e) => {
                const eventId = e.currentTarget.dataset.id;
                navigateTo(`/dashboard/events/edit?id=${eventId}`);
            });
        });

        document.querySelectorAll('.delete-event-btn').forEach(button => {
            button.addEventListener('click', async (e) => {
                const eventId = e.currentTarget.dataset.id;
                if (confirm('¿Estás seguro de que quieres eliminar este evento?')) { 
                    try {
                        await deleteEvent(eventId);
                        showMessage('Evento eliminado exitosamente.', 'success');
                        render();
                    } catch (error) {
                        console.error('Error al eliminar el evento:', error);
                        showMessage(`Error al eliminar el evento: ${error.message}`, 'danger');
                    }
                }
            });
        });
    }

    if (userRole === 'visitor' && currentUser) {
        document.querySelectorAll('.register-event-btn').forEach(button => {
            button.addEventListener('click', async (e) => {
                const eventId = e.currentTarget.dataset.id;
                try {
                    await registerAttendee(eventId, currentUser);
                    showMessage('Te has registrado al evento exitosamente.', 'success');
                    render();
                } catch (error) {
                    console.error('Error al registrarse:', error);
                    showMessage(`Error al registrarse: ${error.message}`, 'danger');
                }
            });
        });

        document.querySelectorAll('.unregister-event-btn').forEach(button => {
            button.addEventListener('click', async (e) => {
                const eventId = e.currentTarget.dataset.id;
                if (confirm('¿Estás seguro de que quieres cancelar tu registro a este evento?')) { 
                    try {
                        await unregisterAttendee(eventId, currentUser);
                        showMessage('Tu registro al evento ha sido cancelado.', 'success');
                        render(); 
                    } catch (error) {
                        console.error('Error al cancelar registro:', error);
                        showMessage(`Error al cancelar registro: ${error.message}`, 'danger');
                    }
                }
            });
        });
    }
}

   