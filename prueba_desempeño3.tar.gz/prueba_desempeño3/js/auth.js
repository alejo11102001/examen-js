const AUTH_API_BASE_URL = 'http://localhost:3000';
const USER_STORAGE_KEY = 'currentUser'; 

export async function registerUser(email, password, role) {
    try {
        const existingUsersResponse = await fetch(`${AUTH_API_BASE_URL}/users?email=${email}`);
        const existingUsers = await existingUsersResponse.json();

        if (existingUsers.length > 0) {
            throw new Error('El correo ya está en uso.');
        }

        const response = await fetch(`${AUTH_API_BASE_URL}/users`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password, role }),
        });

        if (!response.ok) {
            throw new Error('Error al registrar el usuario.');
        }

        const newUser = await response.json();
        return newUser;
    } catch (error) {
        console.error('Error en registerUser:', error);
        throw error;
    }
}

export async function loginUser(email, password) {
    try {
        const response = await fetch(`${AUTH_API_BASE_URL}/users?email=${email}&password=${password}`);
        const users = await response.json();

        if (users.length === 1) {
            const user = users[0];
            localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(user));
            return user;
        } else {
            throw new Error('Credenciales inválidas.');
        }
    } catch (error) {
        console.error('Error en loginUser:', error);
        throw error;
    }
}

export function logoutUser() {
    localStorage.removeItem(USER_STORAGE_KEY);
    console.log('Sesión cerrada.');
}

export function getCurrentUser() {
    const userString = localStorage.getItem(USER_STORAGE_KEY);
    return userString ? JSON.parse(userString) : null;
}

export function isAuthenticated() {
    return getCurrentUser() !== null;
}

export function getUserRole() {
    const user = getCurrentUser();
    return user ? user.role : null;
}