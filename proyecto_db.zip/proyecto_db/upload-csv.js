const fs = require('fs');
const csv = require('csv-parser');
const { Client } = require('pg');

// DBsasa
const client = new Client({
    user: 'root',
    host: '168.119.183.3',
    database: 'diego_z',
    password: 's7cq453mt2jnicTaQXKT',
    port: 5432,
});

async function loadPatientsCSV() {
    try {
        await client.connect();

        const patients = [];
        fs.createReadStream('./back-end/data/patients.csv')
        .pipe(csv())
        .on('data', (data) => {
            patients.push(data);
        })
        .on('end', async () => {
            for (const patient of patients) {
                const query = `
                    INSERT INTO patients (name, email, phone, city)
                    VALUES ($1, $2, $3, $4)
                `;
                const values = [
                    patient.name,
                    patient.email,
                    patient.phone,
                    patient.city,
                ];
                await client.query(query, values);
            }
            console.log('success patients');
            await client.end();
        });

    } catch (err) {
        console.error('Error loading patients:', err);
        await client.end();
    }
}

async function loadDoctorsCSV() {
    try {
        await client.connect();

        const doctors = [];
        fs.createReadStream('./back-end/data/doctors.csv')
        .pipe(csv())
        .on('data', (data) => {
            doctors.push(data);
        })
        .on('end', async () => {
            for (const doctor of doctors) {
                const query = `
                    INSERT INTO doctors (name, specialty)
                    VALUES ($1, $2)
                `;
                const values = [
                    doctor.name,
                    doctor.specialty,
                ];
                await client.query(query, values);
            }
            console.log('success doctors');
            await client.end();
        });

    } catch (err) {
        console.error('Error loading doctors:', err);
        await client.end();
    }
}

async function loadAppointmentsCSV() {
    try {
        await client.connect();

        const appointments = [];
        fs.createReadStream('./back-end/data/appointments.csv')
        .pipe(csv())
        .on('data', (data) => {
            appointments.push(data);
        })
        .on('end', async () => {
            for (const appointment of appointments) {
                const query = `
                    INSERT INTO appointments (location, appointment_datetime, status, payment_method, doctor_id, patient_id)
                    VALUES ($1, $2, $3, $4, $5, $6)
                `;
                const values = [
                    appointment.location,
                    appointment.appointment_datetime,
                    appointment.status,
                    appointment.payment_method,
                    appointment.doctor_id,
                    appointment.patient_id
                ];
                await client.query(query, values);
            }
            console.log('success appointments');
            await client.end();
        });

    } catch (err) {
        console.error('Error loading appointments:', err);
        await client.end();
    }
}

async function loadDiagnosisCSV() {
    try {
        await client.connect();

        const diagnoses = [];
        fs.createReadStream('./back-end/data/diagnosis.csv')
        .pipe(csv())
        .on('data', (data) => {
            diagnoses.push(data);
        })
        .on('end', async () => {
            for (const diagnosis of diagnoses) {
                const query = `
                    INSERT INTO diagnosis (diagnosis, treatment, appointment_id)
                    VALUES ($1, $2, $3)
                `;
                const values = [
                    diagnosis.diagnosis,
                    diagnosis.treatment,
                    diagnosis.appointment_id
                ];
                await client.query(query, values);
            }
            console.log('success diagnoses');
            await client.end();
        });

    } catch (err) {
        console.error('Error loading diagnoses:', err);
        await client.end();
    }
}

const arg = process.argv[2]; // lo que escribiste después de loader.js

if (arg === 'patients') {
    loadPatientsCSV();
} else if (arg === 'doctors') {
    loadDoctorsCSV();
} else if (arg === 'appointments') {
    loadAppointmentsCSV();
} else if (arg === 'diagnosis') {
    loadDiagnosisCSV();
} else {
    console.log('Usa: node upload-csv.js [patients|doctors|appointments|diagnosis]');
}
