(() => {
  const $ = (sel) => document.querySelector(sel);

  // Helpers locales para NO chocar con otros archivos
  const DX_parseRows = (raw) => Array.isArray(raw) ? raw : (raw?.rows || []);

  // ---------- Cargar citas una sola vez (para selects) ----------
  let DX_apptsCache = null;
  async function DX_loadAppointmentsOnce() {
    if (Array.isArray(DX_apptsCache)) return DX_apptsCache;
    const res = await fetch(`${APP_URL}/appointments`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const raw = await res.json(); // /appointments ya devuelve array con nombres
    DX_apptsCache = DX_parseRows(raw);
    return DX_apptsCache;
  }

  function DX_fillAppointmentsSelect(selectEl, appts, selectedId) {
    if (!selectEl) return;
    const opts = ['<option value="" disabled>Seleccione una cita</option>']
      .concat(appts.map(a => {
        const dt = (a.appointment_datetime || '').slice(0,16);
        const label = `${a.id} — ${a.patient_name ?? ''} | ${a.doctor_name ?? ''} | ${dt}`;
        const sel = String(a.id) === String(selectedId) ? 'selected' : '';
        return `<option value="${a.id}" ${sel}>${label}</option>`;
      }));
    selectEl.innerHTML = opts.join('');
  }

  // ---------- API ----------
  async function DX_listDiagnosis() {
    const res = await fetch(`${APP_URL}/diagnosis`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return DX_parseRows(await res.json());
  }

  async function DX_getDiagnosisById(id) {
    const res = await fetch(`${APP_URL}/diagnosis/${id}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const arr = await res.json(); // tu backend devuelve array
    return Array.isArray(arr) ? arr[0] : arr;
  }

  async function DX_updateDiagnosis(id, payload) {
    const res = await fetch(`${APP_URL}/diagnosis/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      const t = await res.text().catch(()=> '');
      throw new Error(`HTTP ${res.status} ${t}`);
    }
    return res.json().catch(()=> ({}));
  }

  async function DX_deleteDiagnosis(id) {
    const res = await fetch(`${APP_URL}/diagnosis/${id}`, { method: 'DELETE' });
    if (!res.ok) {
      const t = await res.text().catch(()=> '');
      throw new Error(`HTTP ${res.status} ${t}`);
    }
  }

  // ---------- Pintar tabla en Home ----------
  const tblDiagnosisBody = $('#tblDiagnosisBody');

  async function reloadDiagnosis() {
    if (!tblDiagnosisBody) return; // no estamos en el Home
    const rows = await DX_listDiagnosis();
    tblDiagnosisBody.innerHTML = '';
    rows.forEach(d => {
      const dt = (d.appointment_datetime || '').slice(0,16);
      tblDiagnosisBody.innerHTML += `
        <tr>
          <td>${d.id}</td>
          <td>${dt}</td>
          <td>${d.patient_name ?? ''}</td>
          <td>${d.doctor_name ?? ''}</td>
          <td>${d.diagnosis}</td>
          <td>${d.treatment}</td>
          <td class="text-end">
            <button class="btn btn-sm btn-primary" data-action="edit" data-id="${d.id}" data-name="${d.patient_name ?? ''}">Editar</button>
            <button class="btn btn-sm btn-danger"  data-action="delete" data-id="${d.id}" data-name="${d.patient_name ?? ''}">Eliminar</button>
          </td>
        </tr>
      `;
    });
  }

  // Cargar al abrir (si existe esa tabla)
  (async () => { try { await reloadDiagnosis(); } catch {} })();

  // ---------- Abrir modal con datos ----------
  async function showDiagnosis(id) {
    try {
      const d = await DX_getDiagnosisById(id); // {id, appointment_id, diagnosis, treatment, ...}
      if (!d) throw new Error('Diagnóstico no encontrado');

      // Llenar select de citas
      const appts = await DX_loadAppointmentsOnce();
      DX_fillAppointmentsSelect($('#diagnosisAppointmentId'), appts, d.appointment_id);

      // Llenar campos (IDs que tienes en el HTML)
      $('#diagnosisId').value         = d.id;
      $('#diagnosisText').value       = d.diagnosis ?? '';
      $('#diagnosisTreatment').value  = d.treatment ?? '';

      // Mostrar modal
      bootstrap.Modal.getOrCreateInstance(
        document.getElementById('exampleModalDiagnosis')
      ).show();

    } catch (err) {
      console.error('Error en showDiagnosis:', err);
      alert('No se pudo cargar el diagnóstico.');
    }
  }

  // ---------- Guardar cambios (submit del modal) ----------
  window.addEventListener('DOMContentLoaded', () => {
    const frm = document.getElementById('frmEditDiagnosis');
    if (!frm) return;

    frm.addEventListener('submit', async (e) => {
      e.preventDefault();
      try {
        const id   = $('#diagnosisId')?.value;
        const app  = $('#diagnosisAppointmentId')?.value;
        const diag = $('#diagnosisText')?.value?.trim();
        const trt  = $('#diagnosisTreatment')?.value?.trim();

        if (!id || !app || !diag || !trt) {
          alert('Completa todos los campos.');
          return;
        }

        await DX_updateDiagnosis(id, {
          appointment_id: Number(app),
          diagnosis: diag,
          treatment: trt
        });

        bootstrap.Modal.getOrCreateInstance(
          document.getElementById('exampleModalDiagnosis')
        ).hide();

        await reloadDiagnosis();
        alert('Diagnóstico actualizado');

      } catch (err) {
        console.error('Error al actualizar diagnóstico:', err);
        alert('No se pudo actualizar: ' + err.message);
      }
    });
  });

  // ---------- Delegación de eventos en la tabla ----------
  if (tblDiagnosisBody) {
    tblDiagnosisBody.addEventListener('click', (e) => {
      const btn = e.target.closest('button.btn-sm');
      if (!btn) return;

      const id = btn.dataset.id;
      const name = btn.dataset.name;
      const action = btn.dataset.action;
      if (!id || !action) return;

      if (action === 'edit') {
        showDiagnosis(id);
      } else if (action === 'delete') {
        (async () => {
          try {
            const ok = confirm(`¿Eliminar diagnóstico de ${name ? `"${name}"` : `#${id}`}?`);
            if (!ok) return;
            await DX_deleteDiagnosis(id);
            await reloadDiagnosis();
            alert('Diagnóstico eliminado');
          } catch (err) {
            console.error('Error al eliminar diagnóstico:', err);
            alert('No se pudo eliminar: ' + err.message);
          }
        })();
      }
    });
  }

  // ====== SOPORTE PARA createDiagnosis.html (CREAR) ======
window.addEventListener('DOMContentLoaded', () => {
  const formCreate   = document.querySelector('#frmDiagnosis');     // <form> de crear
  const msg          = document.querySelector('#msg');              // div de mensajes
  const selAppt      = document.querySelector('#appointmentId');    // <select> de cita
  const selDoctorOpt = document.querySelector('#doctorId');         // opcional (si lo tienes)
  const lblPatient   = document.querySelector('#patientNamePreview'); // opcional <span> o <input readonly>
  const lblDoctor    = document.querySelector('#doctorNamePreview');  // opcional

  // Rellena selects al abrir la página de crear
  (async () => {
    try {
      if (selAppt) {
        const appts = await DX_loadAppointmentsOnce(); // usa /appointments (incluye patient_name y doctor_name)
        // Reutilizamos la función que ya tienes, pero con selectedId vacío
        DX_fillAppointmentsSelect(selAppt, appts, '');

        // Si quieres que se muestre el paciente/doctor al cambiar la cita
        selAppt.addEventListener('change', () => {
          const a = appts.find(x => String(x.id) === String(selAppt.value));
          if (lblPatient) lblPatient.textContent = a?.patient_name ?? '';
          if (lblDoctor)  lblDoctor.textContent  = a?.doctor_name  ?? '';
        });
      }

      // Si además quieres un select independiente de doctores (OPCIONAL)
      if (selDoctorOpt) {
        const resD = await fetch(`${APP_URL}/doctors`);
        if (!resD.ok) throw new Error(`HTTP ${resD.status}`);
        const doctors = DX_parseRows(await resD.json());
        selDoctorOpt.innerHTML = [
          '<option value="" disabled selected>Seleccione un doctor</option>',
          ...doctors.map(d => `<option value="${d.id}">${d.name}${d.specialty ? ' — ' + d.specialty : ''}</option>`)
        ].join('');
      }
    } catch (err) {
      console.error('Error cargando selects (crear diagnóstico):', err);
      if (msg) msg.innerHTML = `<div class="alert alert-danger mb-0">No se pudieron cargar las citas/doctores.</div>`;
    }
  })();

  if (!formCreate) return; // si este archivo también se carga en otras páginas

  // Enviar crear diagnóstico
  formCreate.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (msg) msg.innerHTML = '';

    const fd = new FormData(formCreate);
    const payload = {
      appointment_id: Number(fd.get('appointment_id')),   // name="appointment_id" en tu <select>
      diagnosis: (fd.get('diagnosis') || '').trim(),      // name="diagnosis"
      treatment: (fd.get('treatment') || '').trim()       // name="treatment"
    };

    // Validación mínima
    if (!payload.appointment_id || !payload.diagnosis || !payload.treatment) {
      if (msg) msg.innerHTML = `<div class="alert alert-warning mb-0">Completa todos los campos.</div>`;
      return;
    }

    try {
      const res = await fetch(`${APP_URL}/diagnosis`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!res.ok) {
        const t = await res.text().catch(()=>'');
        throw new Error(`HTTP ${res.status} ${t}`);
      }

      await res.json().catch(()=> ({}));
      if (msg) msg.innerHTML = `<div class="alert alert-success mb-0">Diagnóstico creado</div>`;
      formCreate.reset();
      // Limpia previews
      if (lblPatient) lblPatient.textContent = '';
      if (lblDoctor)  lblDoctor.textContent  = '';

    } catch (err) {
      console.error('Error creando diagnóstico:', err);
      if (msg) msg.innerHTML = `<div class="alert alert-danger mb-0">Error al crear diagnóstico: ${err.message}</div>`;
    }
  });
});
})();
