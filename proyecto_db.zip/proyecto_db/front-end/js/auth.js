// config.js debe definir APP_URL, ej: const APP_URL = 'http://localhost:3000';

(function () {
  const $ = (sel) => document.querySelector(sel);

  // ---------- LOGIN ----------
  const loginForm = $('#form-login');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(loginForm);
      const payload = {
        correo: fd.get('correo')?.trim(),
        contraseña: fd.get('contraseña')?.trim()
      };

      if (!payload.correo || !payload.contraseña) {
        alert('Completa correo y contraseña');
        return;
      }

      try {
        const res = await fetch(`${APP_URL}/auth/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const data = await res.json().catch(()=> ({}));

        if (!res.ok) {
          alert(data?.error || `Error HTTP ${res.status}`);
          return;
        }

        // Guarda token y usuario
        localStorage.setItem('token', data.token);
        localStorage.setItem('user', JSON.stringify(data.user));

        alert('Inicio de sesión exitoso');
        // Redirige
        location.href = './home.html';
      } catch (err) {
        console.error(err);
        alert('No se pudo iniciar sesión');
      }
    });
  }

  // ---------- REGISTER ----------
  const registerForm = $('#form-register');
  if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(registerForm);
      const payload = {
        nombres:     fd.get('nombres')?.trim(),
        apellidos:   fd.get('apellidos')?.trim(),
        correo:      fd.get('correo')?.trim(),
        contraseña:  fd.get('contraseña')?.trim()
      };

      if (!payload.nombres || !payload.apellidos || !payload.correo || !payload.contraseña) {
        alert('Completa todos los campos');
        return;
      }

      try {
        const res = await fetch(`${APP_URL}/auth/register`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        const data = await res.json().catch(()=> ({}));

        if (!res.ok) {
          alert(data?.error || `Error HTTP ${res.status}`);
          return;
        }

        // Guarda token y usuario
        localStorage.setItem('token', data.token);
        localStorage.setItem('user', JSON.stringify(data.user));
        // Redirige
        alert('Registro exitoso');
        location.href = './login.html';
      } catch (err) {
        console.error(err);
        alert('No se pudo registrar');
      }
    });
  }

  // ---------- Helper para usar token en fetch (opcional) ----------
//   window.authFetch = async (url, options = {}) => {
//     const token = localStorage.getItem('token');
//     const headers = new Headers(options.headers || {});
//     if (token) headers.set('Authorization', `Bearer ${token}`);
//     headers.set('Content-Type', headers.get('Content-Type') || 'application/json');
//     const res = await fetch(url, { ...options, headers });
//     return res;
//   };

})();
