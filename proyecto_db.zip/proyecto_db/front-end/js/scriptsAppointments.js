const tblAppointmentsBody = document.getElementById('tblAppointmentsBody');
const formEditAppointment = document.getElementById('frmEditAppointment');

// Helpers
const parseRows = (raw) => Array.isArray(raw) ? raw : (raw?.rows || []);
const showMsg = (el, text, type='info') => { if (el) el.innerHTML = `<div class="alert alert-${type} mb-0">${text}</div>`; };
const toPgTimestamp = (value) => value && value.includes('T') ? value.replace('T',' ') + ':00' : '';

let doctorsCache = null;

async function loadDoctorsOnce() {
  if (Array.isArray(doctorsCache)) return doctorsCache;
  const res = await fetch(`${APP_URL}/doctors`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const raw = await res.json();
  doctorsCache = Array.isArray(raw) ? raw : (raw.rows || []);
  return doctorsCache;
}

function fillDoctorsSelect(selectEl, doctors, selectedId) {
  if (!selectEl) return;
  const opts = ['<option value="" disabled>Seleccione un doctor</option>']
    .concat(doctors.map(d => 
      `<option value="${d.id}" ${String(d.id)===String(selectedId)?'selected':''}>
        ${d.name}${d.specialty ? ' — ' + d.specialty : ''}
      </option>`
    ));
  selectEl.innerHTML = opts.join('');
}

// ===================== CREATE =====================
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('frmAppointment');
  const msg  = document.getElementById('msg');

  // Si esta página tiene el form de crear, también llenamos selects
  const selPatient = document.getElementById('patientId');
  const selDoctor  = document.getElementById('doctorId');

  // Llenar selects (si existen)
  (async function loadSelects() {
    try {
      if (selPatient) {
        const rp = await fetch(`${APP_URL}/patients`);
        const patients = parseRows(await rp.json());
        selPatient.innerHTML = ['<option value="" disabled selected>Seleccione un paciente</option>']
          .concat(patients.map(p => `<option value="${p.id}">${p.name} (${p.id})</option>`))
          .join('');
      }
      if (selDoctor) {
        const rd = await fetch(`${APP_URL}/doctors`);
        const doctors = parseRows(await rd.json());
        selDoctor.innerHTML = ['<option value="" disabled selected>Seleccione un doctor</option>']
          .concat(doctors.map(d => `<option value="${d.id}">${d.name}${d.specialty ? ' — ' + d.specialty : ''}</option>`))
          .join('');
      }
    } catch (err) {
      console.error('Error cargando selects:', err);
      showMsg(msg, 'No se pudieron cargar pacientes/doctores.', 'danger');
    }
  })();

  if (!form) return; // si este script se carga en otras páginas

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (msg) msg.innerHTML = '';

    const fd = new FormData(form);
    const payload = {
      location:              fd.get('location')?.trim(),
      appointment_datetime:  toPgTimestamp(fd.get('appointment_datetime')?.trim()),
      status:                fd.get('status')?.trim(),
      payment_method:        fd.get('payment_method')?.trim(),
      doctor_id:             Number(fd.get('doctor_id')),
      patient_id:            Number(fd.get('patient_id')),
    };

    if (!payload.location || !payload.appointment_datetime || !payload.status || !payload.payment_method || !payload.doctor_id || !payload.patient_id) {
      return showMsg(msg, 'Completa todos los campos.', 'warning');
    }

    try {
      const res = await fetch(APP_URL + '/appointments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const text = await res.text().catch(()=> '');
        throw new Error(`HTTP ${res.status} ${text}`);
      }

      await res.json().catch(()=> ({}));
      showMsg(msg, 'Cita creada', 'success');
      form.reset();

    } catch (err) {
      console.error('Error en POST:', err);
      showMsg(msg, 'Error al crear cita: ' + err.message, 'danger');
    }
  });
});

// ===================== LISTAR =====================
async function reloadAppointments() {
  const res = await fetch(APP_URL + '/appointments');
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = await res.json();
  const rows = parseRows(data);

  if (!tblAppointmentsBody) return;
  tblAppointmentsBody.innerHTML = '';
  rows.forEach(appointment => {
    tblAppointmentsBody.innerHTML += `
      <tr>
        <td>${appointment.id}</td>
        <td>${appointment.appointment_datetime}</td>
        <td>${appointment.patient_name ?? ''}</td>
        <td>${appointment.doctor_name ?? ''}</td>
        <td>${appointment.status}</td>
        <td>${appointment.payment_method}</td>
        <td>${appointment.location}</td>
        <td class="text-end">
          <button class="btn btn-sm btn-primary" data-action="edit" data-id="${appointment.id}" data-name="${appointment.patient_name ?? ''}">Editar</button>
          <button class="btn btn-sm btn-danger"  data-action="delete" data-id="${appointment.id}" data-name="${appointment.patient_name ?? ''}">Eliminar</button>
        </td>
      </tr>
    `;
  });
}

// Cargar al abrir
(async function index() {
  try {
    await reloadAppointments();
  } catch (error) {
    console.error('Error en GET:', error);
  }
})();

// ===================== UPDATE (API) =====================
async function updateAppointment(id, payload) {
  const res = await fetch(`${APP_URL}/appointments/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`HTTP ${res.status} ${text}`);
  }
  return res.json().catch(() => ({}));
}

// ===================== UPDATE (DOM) =====================
window.addEventListener('DOMContentLoaded', () => {
  const frm = document.getElementById('frmEditAppointment');
  if (!frm) return;

  frm.addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      const id     = document.getElementById('appointmentId').value;
      const dtRaw  = document.getElementById('appointmentDatetime').value.trim();
      const status = document.getElementById('appointmentStatus').value.trim();
      const pay    = document.getElementById('appointmentPaymentMethod').value.trim();
      const loc    = document.getElementById('appointmentLocation').value.trim();

      const patientIdEl = document.getElementById('appointmentPatientId'); // hidden
      const doctorSelEl = document.getElementById('appointmentDoctorId');  // select

      const payload = {
        appointment_datetime: toPgTimestamp(dtRaw),
        status,
        payment_method: pay,
        location: loc
      };
      if (patientIdEl && patientIdEl.value) payload.patient_id = Number(patientIdEl.value);
      if (doctorSelEl && doctorSelEl.value) payload.doctor_id  = Number(doctorSelEl.value);

      const res = await fetch(`${APP_URL}/appointments/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!res.ok) {
        const t = await res.text().catch(()=> '');
        throw new Error(`HTTP ${res.status} ${t}`);
      }

      // Cerrar modal y refrescar
      bootstrap.Modal.getOrCreateInstance(
        document.getElementById('exampleModalAppointment')
      ).hide();

      await reloadAppointments();
      alert('Cita actualizada');
    } catch (err) {
      console.error('Error en PUT:', err);
      alert('No se pudo actualizar: ' + err.message);
    }
  });
});


// ===================== DELETE =====================
async function deleteAppointment(id, name) {
  try {
    const nameLabel = name ? `"${name}"` : `#${id}`;
    const ok = confirm(`¿Eliminar cita ${nameLabel}?`);
    if (!ok) return;

    const res = await fetch(`${APP_URL}/appointments/${id}`, { method: 'DELETE' });
    if (!res.ok) {
      const t = await res.text().catch(() => '');
      throw new Error(`HTTP ${res.status} ${t}`);
    }

    await reloadAppointments();
    alert(`Cita ${nameLabel} eliminada`);

  } catch (error) {
    console.error('Error en DELETE:', error);
    alert('No se pudo eliminar: ' + error.message);
  }
}

// ===================== EDIT (abrir modal) =====================
if (tblAppointmentsBody) {
  tblAppointmentsBody.addEventListener('click', (e) => {
    const btn = e.target.closest('button.btn-sm');
    if (!btn) return;

    const id = btn.dataset.id;
    const name = btn.dataset.name;
    const action = btn.dataset.action;
    if (!id || !action) return;

    if (action === 'edit') {
      showAppointment(id);
    } else if (action === 'delete') {
      deleteAppointment(id, name);
    }
  });
}

function setVal(id, value) {
  const el = document.getElementById(id);
  if (!el) {
    console.warn(`[showAppointment] Falta #${id} en el DOM`);
    return;
  }
  el.value = value ?? '';
}

async function showAppointment(id) {
  try {
    const res = await fetch(`${APP_URL}/appointments/${id}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const raw = await res.json();
    const ap = Array.isArray(raw) ? raw[0] : (raw?.rows ? raw.rows[0] : raw);

    // Fecha/hora al formato de <input type="datetime-local">
    const dtLocal = ap.appointment_datetime
      ? ap.appointment_datetime.replace(' ', 'T').slice(0,16)
      : '';

    // 1) Set patient (nombre visible, id oculto)
    setVal('appointmentId', ap.id);
    setVal('appointmentPatientId', ap.patient_id);
    setVal('appointmentPatientName', ap.patient_name ?? '');

    // 2) Llenar SELECT de doctores y seleccionar el actual
    const doctors = await loadDoctorsOnce();
    fillDoctorsSelect(document.getElementById('appointmentDoctorId'), doctors, ap.doctor_id);

    // 3) Resto de campos
    setVal('appointmentDatetime', dtLocal);
    setVal('appointmentStatus', ap.status);
    setVal('appointmentPaymentMethod', ap.payment_method);
    setVal('appointmentLocation', ap.location);

    // Mostrar modal
    const modalEl = document.getElementById('exampleModalAppointment');
    bootstrap.Modal.getOrCreateInstance(modalEl).show();

  } catch (error) {
    console.error('Error en showAppointment:', error);
    alert('No se pudieron cargar los datos de la cita.');
  }
}

