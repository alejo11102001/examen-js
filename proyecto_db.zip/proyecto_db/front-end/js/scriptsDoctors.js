const tblDoctorsBody = document.getElementById('tblDoctorsBody');
const formEditDoctor = document.getElementById('frmEditDoctor');

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('frmDoctor');
    const msg  = document.getElementById('msg');

    if (!form) {
        console.error('No existe #frmDoctor en el DOM');
        return;
    }

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (msg) msg.innerHTML = '';

        const formData = new FormData(form);
        const payload = {
        name:  formData.get('name')?.trim(),
        specialty: formData.get('specialty')?.trim()
        };

        if (!payload.name || !payload.specialty) {
        if (msg) msg.innerHTML = `<div class="alert alert-danger">Completa todos los campos.</div>`;
        return;
        }

        try {
        const res = await fetch(APP_URL + '/doctors', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (!res.ok) {
            const text = await res.text().catch(()=>'');
            throw new Error(`HTTP ${res.status} ${text}`);
        }

        const data = await res.json().catch(()=> ({}));
        if (msg) msg.innerHTML = `<div class="alert alert-success">Doctor creado</div>`;
        form.reset();

        } catch (err) {
        console.error('Error en POST:', err);
        if (msg) msg.innerHTML = `<div class="alert alert-danger">Error al crear doctor: ${err.message}</div>`;
        }
    });
});

// Nueva función para recargar la tabla (la usará la IIFE y también update/delete)
async function reloadDoctors() {
    const res = await fetch(APP_URL + '/doctors');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const rows = Array.isArray(data) ? data : (data.rows || []);

    if (!tblDoctorsBody) return;
    tblDoctorsBody.innerHTML = '';
    rows.forEach(doctor => {
        tblDoctorsBody.innerHTML += `
        <tr>
            <td>${doctor.id}</td>
            <td>${doctor.name}</td>
            <td>${doctor.specialty}</td>
            <td class="text-end">
            <button class="btn btn-sm btn-primary" data-action="edit" data-id="${doctor.id}" data-name="${doctor.name}">Editar</button>
            <button class="btn btn-sm btn-danger"  data-action="delete" data-id="${doctor.id}" data-name="${doctor.name}">Eliminar</button>
            </td>
        </tr>
        `;
    });
}

    //Mantienes tu IIFE auto-invocada para cargar al abrir
(async function index() {
    try {
        await reloadDoctors();   // solo llamamos la función auxiliar
    } catch (error) {
        console.error('Error en GET:', error);
    }
})();

// === API: solo fetch, sin tocar el DOM ===
async function updateDoctor(id, payload) {
    const res = await fetch(`${APP_URL}/doctors/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    });
    if (!res.ok) {
        const text = await res.text().catch(() => '');
        throw new Error(`HTTP ${res.status} ${text}`);
    }
    // devuelve el paciente actualizado (si tu backend hace RETURNING *)
    return res.json().catch(() => ({}));
}

// DOM: solo orquesta lectura del form, llamada a la API y UI ===
window.addEventListener('DOMContentLoaded', () => {
    const frm = document.getElementById('frmEditDoctor');

    frm.addEventListener('submit', async (e) => {
        e.preventDefault();

        try {
        const id    = document.getElementById('doctorId').value;
        const name  = document.getElementById('doctorName').value.trim();
        const specialty = document.getElementById('doctorSpecialty').value.trim();

        await updateDoctor(id, { name, specialty });

        // Cerrar modal
        bootstrap.Modal.getOrCreateInstance(
            document.getElementById('exampleModalDoctor')
        ).hide();

        // Refrescar tabla y avisar
        await reloadDoctors();
        alert('Doctor actualizado');

        } catch (err) {
        console.error('Error en PUT:', err);
        alert('No se pudo actualizar: ' + err.message);
        }
    });
});

// --- DELETE ---
async function deleteDoctor(id, name) {
    try {
        // usar el nombre que viene en el botón
        let nameLabel = name ? `"${name}"` : `#${id}`;

        // confirmar
        const ok = confirm(`¿Eliminar doctor ${nameLabel}?`);
        if (!ok) return;

        // petición DELETE
        const res = await fetch(`${APP_URL}/doctors/${id}`, { method: 'DELETE' });
        if (!res.ok) {
        const t = await res.text().catch(() => '');
        throw new Error(`HTTP ${res.status} ${t}`);
        }

        await reloadDoctors();                  // refresca tabla
        // aviso
        alert(`Doctor ${nameLabel} eliminado`);

    } catch (error) {
        console.error('Error en DELETE:', error);
        alert('No se pudo eliminar: ' + error.message);
    }
}

// --- Delegación de eventos SOLO en la tabla de doctores ---
if (tblDoctorsBody) {
    tblDoctorsBody.addEventListener('click', (e) => {
        const btn = e.target.closest('button.btn-sm');
        if (!btn) return;

        const id = btn.dataset.id;
        const name = btn.dataset.name;
        const action = btn.dataset.action;
        if (!id || !action) return;

        if (action === 'edit') {
            showDoctor(id);
        } else if (action === 'delete') {
            deleteDoctor(id, name);
        }
    });
}

async function showDoctor(id){
    try {
        const res = await fetch(`${APP_URL}/doctors/${id}`);
        if (!res.ok) {
            throw new Error(`Error HTTP ${res.status} al buscar el doctor.`);
        }
        const doctor = await res.json(); // doctor es un array: [{...}]

        // ¡Este console.log es tu mejor amigo para depurar!
        // Abre la consola del navegador (F12) y verás exactamente qué te devuelve la API.
        console.log('Datos recibidos de la API:', doctor);

        // 👇 VOLVEMOS A USAR [0] PORQUE TU API DEVUELVE UN ARRAY
        document.getElementById('doctorId').value = doctor[0].id;
        document.getElementById('doctorName').value = doctor[0].name;
        document.getElementById('doctorSpecialty').value = doctor[0].specialty;

        // Mostrar el modal
        const modalElement = document.getElementById('exampleModalDoctor');
        const modal = bootstrap.Modal.getOrCreateInstance(modalElement);
        modal.show();

    } catch (error) {
        console.error('Error en showDoctor:', error);
        alert('No se pudieron cargar los datos del doctor.');
    }
}