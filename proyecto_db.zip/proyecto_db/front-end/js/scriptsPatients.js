const tblPatientsBody = document.getElementById('tblPatientsBody');
const formEditPatient = document.getElementById('frmEditPatient');

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('frmPatient');
    const msg  = document.getElementById('msg');

    if (!form) {
        console.error('No existe #frmPatient en el DOM');
        return;
    }

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (msg) msg.innerHTML = '';

        const formData = new FormData(form);
        const payload = {
        name:  formData.get('name')?.trim(),
        email: formData.get('email')?.trim(),
        phone: formData.get('phone')?.trim(),
        city:  formData.get('city')?.trim()
        };

        if (!payload.name || !payload.email || !payload.phone || !payload.city) {
        if (msg) msg.innerHTML = `<div class="alert alert-danger">Completa todos los campos.</div>`;
        return;
        }

        try {
        const res = await fetch(APP_URL + '/patients', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (!res.ok) {
            const text = await res.text().catch(()=>'');
            throw new Error(`HTTP ${res.status} ${text}`);
        }

        const data = await res.json().catch(()=> ({}));
        if (msg) msg.innerHTML = `<div class="alert alert-success">Paciente creado</div>`;
        form.reset();

        } catch (err) {
        console.error('Error en POST:', err);
        if (msg) msg.innerHTML = `<div class="alert alert-danger">Error al crear paciente: ${err.message}</div>`;
        }
    });
});

// Nueva función para recargar la tabla (la usará la IIFE y también update/delete)
async function reloadPatients() {
    const res = await fetch(APP_URL + '/patients');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const rows = Array.isArray(data) ? data : (data.rows || []);

    if (!tblPatientsBody) return;
    tblPatientsBody.innerHTML = '';
    rows.forEach(patient => {
        tblPatientsBody.innerHTML += `
        <tr>
            <td>${patient.id}</td>
            <td>${patient.name}</td>
            <td>${patient.email}</td>
            <td>${patient.phone}</td>
            <td>${patient.city}</td>
            <td class="text-end">
            <button class="btn btn-sm btn-primary" data-action="edit" data-id="${patient.id}" data-name="${patient.name}">Editar</button>
            <button class="btn btn-sm btn-danger"  data-action="delete" data-id="${patient.id}" data-name="${patient.name}">Eliminar</button>
            </td>
        </tr>
        `;
    });
}

    //Mantienes tu IIFE auto-invocada para cargar al abrir
(async function index() {
    try {
        await reloadPatients();   // solo llamamos la función auxiliar
    } catch (error) {
        console.error('Error en GET:', error);
    }
})();

// === API: solo fetch, sin tocar el DOM ===
async function updatePatient(id, payload) {
    const res = await fetch(`${APP_URL}/patients/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    });
    if (!res.ok) {
        const text = await res.text().catch(() => '');
        throw new Error(`HTTP ${res.status} ${text}`);
    }
    // devuelve el paciente actualizado (si tu backend hace RETURNING *)
    return res.json().catch(() => ({}));
}

// DOM: solo orquesta lectura del form, llamada a la API y UI ===
window.addEventListener('DOMContentLoaded', () => {
    const frm = document.getElementById('frmEditPatient');

    frm.addEventListener('submit', async (e) => {
        e.preventDefault();

        try {
        const id    = document.getElementById('patientId').value;
        const name  = document.getElementById('patientName').value.trim();
        const email = document.getElementById('patientEmail').value.trim();
        const phone = document.getElementById('patientPhone').value.trim();
        const city  = document.getElementById('patientCity').value.trim();

        await updatePatient(id, { name, email, phone, city });

        // Cerrar modal
        bootstrap.Modal.getOrCreateInstance(
            document.getElementById('exampleModalPatient')
        ).hide();

        // Refrescar tabla y avisar
        await reloadPatients();
        alert('Paciente actualizado');

        } catch (err) {
        console.error('Error en PUT:', err);
        alert('No se pudo actualizar: ' + err.message);
        }
    });
});

// --- DELETE ---
async function deletePatient(id, name) {
    try {
        // usar el nombre que viene en el botón
        let nameLabel = name ? `"${name}"` : `#${id}`;

        // confirmar
        const ok = confirm(`¿Eliminar paciente ${nameLabel}?`);
        if (!ok) return;

        // petición DELETE
        const res = await fetch(`${APP_URL}/patients/${id}`, { method: 'DELETE' });
        if (!res.ok) {
        const t = await res.text().catch(() => '');
        throw new Error(`HTTP ${res.status} ${t}`);
        }

        await reloadPatients();                  // refresca tabla
        // aviso
        alert(`Paciente ${nameLabel} eliminado`);

    } catch (error) {
        console.error('Error en DELETE:', error);
        alert('No se pudo eliminar: ' + error.message);
    }
}

// --- Delegación de eventos SOLO en la tabla de pacientes ---
if (tblPatientsBody) {
    tblPatientsBody.addEventListener('click', (e) => {
        const btn = e.target.closest('button.btn-sm');
        if (!btn) return;

        const id = btn.dataset.id;
        const name = btn.dataset.name;
        const action = btn.dataset.action;
        if (!id || !action) return;

        if (action === 'edit') {
            showPatient(id);
        } else if (action === 'delete') {
            deletePatient(id, name);
        }
    });
}


async function showPatient(id){
    try {
        const res = await fetch(`${APP_URL}/patients/${id}`);
        if (!res.ok) {
            throw new Error(`Error HTTP ${res.status} al buscar el paciente.`);
        }
        const patient = await res.json(); // patient es un array: [{...}]

        // ¡Este console.log es tu mejor amigo para depurar!
        // Abre la consola del navegador (F12) y verás exactamente qué te devuelve la API.
        console.log('Datos recibidos de la API:', patient);

        // 👇 VOLVEMOS A USAR [0] PORQUE TU API DEVUELVE UN ARRAY
        document.getElementById('patientId').value = patient[0].id;
        document.getElementById('patientName').value = patient[0].name;
        document.getElementById('patientEmail').value = patient[0].email;
        document.getElementById('patientPhone').value = patient[0].phone;
        document.getElementById('patientCity').value = patient[0].city;

        // Mostrar el modal
        const modalElement = document.getElementById('exampleModalPatient');
        const modal = bootstrap.Modal.getOrCreateInstance(modalElement);
        modal.show();

    } catch (error) {
        console.error('Error en showPatient:', error);
        alert('No se pudieron cargar los datos del paciente.');
    }
}