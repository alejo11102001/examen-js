const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'super-secretito-cambia-esto'; // cambia en prod
const JWT_EXPIRES_IN = '7d';

const app = express();
app.use(express.json());
app.use(cors())

// Configura tu conexión a PostgreSQL
const pool = new Pool({
    user: 'root',
    host: '168.119.183.3',
    database: 'diego_z',
    password: 's7cq453mt2jnicTaQXKT',
    port: 5432
});

//PATIENTS

app.get("/patients", async (req, res) => {
    try {
        let result = await pool.query("SELECT * FROM patients order by id desc");
        return res.json(result);
    } catch (error) {
        res.status(500).json({error : 'error'})
    }
});

app.get("/patients/:id", async (req, res) => {
    try {
        let result = await pool.query("SELECT * FROM patients WHERE id = $1", [req.params.id]);
        return res.json(result.rows);
    } catch (error) {
        res.status(500).json({error : 'error'})
    }
});

app.post('/patients', async (req, res) => {
    const { name, email, phone, city } = req.body;
    try {
        const result = await pool.query(
        'INSERT INTO patients (name, email, phone, city) VALUES ($1, $2, $3, $4) RETURNING *',
        [name, email, phone, city]
        );
        res.status(201).json(result.rows[0]);
    } catch (error) {
        res.status(500).json({ error: 'Error al crear el paciente' });
    }
});

app.put('/patients/:id', async (req, res) => {
    const { id } = req.params;
    const { name, email, phone, city } = req.body;
    try {
        const result = await pool.query(
            'UPDATE patients SET name = $1, email = $2, phone = $3, city = $4 WHERE id = $5 RETURNING *',
            [name, email, phone, city, id]
        );
        if (result.rowCount === 0) {
            return res.status(404).json({ error: 'Paciente no encontrado' });
        }
        res.json({ message: 'Paciente actualizado' });
    } catch (error) {
        res.status(500).json({ error: 'Error al actualizar el paciente' });
    }
});

app.delete('/patients/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const result = await pool.query('DELETE FROM patients WHERE id = $1 RETURNING *', [id]);
        if (result.rows.length === 0) return res.status(404).json({ error: 'Paciente no encontrado' });
        res.json({ mensaje: 'Paciente eliminado' });
    } catch (error) {
        res.status(500).json({ error: 'Error al eliminar el paciente' });
    }
});

//DOCTORS

app.get("/doctors", async (req, res) => {
    try {
        let result = await pool.query("SELECT * FROM doctors order by id desc");
        return res.json(result);
    } catch (error) {
        res.status(500).json({error : 'error'})
    }
});

app.get("/doctors/:id", async (req, res) => {
    try {
        let result = await pool.query("SELECT * FROM doctors WHERE id = $1", [req.params.id]);
        return res.json(result.rows);
    } catch (error) {
        res.status(500).json({error : 'error'})
    }
});

app.post('/doctors', async (req, res) => {
    const { name, specialty } = req.body;
    try {
        const result = await pool.query(
        'INSERT INTO doctors (name, specialty) VALUES ($1, $2) RETURNING *',
        [name, specialty]
        );
        res.status(201).json(result.rows[0]);
    } catch (error) {
        res.status(500).json({ error: 'Error al crear el doctor' });
    }
});

app.put('/doctors/:id', async (req, res) => {
    const { id } = req.params;
    const { name, specialty } = req.body;
    try {
        const result = await pool.query(
            'UPDATE doctors SET name = $1, specialty = $2 WHERE id = $3 RETURNING *',
            [name, specialty, id]
        );
        if (result.rowCount === 0) {
            return res.status(404).json({ error: 'Doctor no encontrado' });
        }
        res.json({ message: 'Doctor actualizado' });
    } catch (error) {
        res.status(500).json({ error: 'Error al actualizar el doctor' });
    }
});

app.delete('/doctors/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const result = await pool.query('DELETE FROM doctors WHERE id = $1 RETURNING *', [id]);
        if (result.rows.length === 0) return res.status(404).json({ error: 'Doctor no encontrado' });
        res.json({ mensaje: 'Doctor eliminado' });
    } catch (error) {
        res.status(500).json({ error: 'Error al eliminar el doctor' });
    }
});

//APPOINTMENTS

app.get('/appointments', async (req, res) => {
    try {
        const result = await pool.query(`
        SELECT 
            a.id,
            a.appointment_datetime,
            p.name AS patient_name,
            d.name AS doctor_name,
            a.status,
            a.payment_method,
            a.location
        FROM appointments a
        JOIN patients p ON a.patient_id = p.id
        JOIN doctors d ON a.doctor_id = d.id
        `);

        res.json(result.rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Error al obtener citas' });
    }
});


// GET /appointments/:id  -> con JOIN y alias patient_name / doctor_name
app.get('/appointments/:id', async (req, res) => {
    try {
        const sql = `
        SELECT 
            a.id,
            a.appointment_datetime,
            a.status,
            a.payment_method,
            a.location,
            a.patient_id,
            p.name AS patient_name,
            a.doctor_id,
            d.name AS doctor_name
        FROM appointments a
        JOIN patients  p ON p.id = a.patient_id
        JOIN doctors   d ON d.id = a.doctor_id
        WHERE a.id = $1
        `;
        const result = await pool.query(sql, [req.params.id]);
        return res.json(result.rows); // tu front espera un array
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Error al obtener la cita' });
    }
});


app.post('/appointments', async (req, res) => {
    const { location, appointment_datetime, status, payment_method, doctor_id, patient_id } = req.body;
    try {
        const result = await pool.query(
        'INSERT INTO appointments (location, appointment_datetime, status, payment_method, doctor_id, patient_id) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
        [location, appointment_datetime, status, payment_method, doctor_id, patient_id]
        );
        res.status(201).json(result.rows[0]);
    } catch (error) {
        res.status(500).json({ error: 'Error al crear la cita' });
    }
});

app.put('/appointments/:id', async (req, res) => {
    const { id } = req.params;
    const { location, appointment_datetime, status, payment_method, doctor_id, patient_id } = req.body;
    try {
        const result = await pool.query(
            'UPDATE appointments SET location = $1, appointment_datetime = $2, status = $3, payment_method = $4, doctor_id = $5, patient_id = $6 WHERE id = $7 RETURNING *',
            [location, appointment_datetime, status, payment_method, doctor_id, patient_id, id]
        );
        if (result.rowCount === 0) {
            return res.status(404).json({ error: 'Cita no encontrada' });
        }
        res.json({ message: 'Cita actualizada' });
    } catch (error) {
        res.status(500).json({ error: 'Error al actualizar la cita' });
    }
});

app.delete('/appointments/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const result = await pool.query('DELETE FROM appointments WHERE id = $1 RETURNING *', [id]);
        if (result.rows.length === 0) return res.status(404).json({ error: 'Cita no encontrada' });
        res.json({ mensaje: 'Cita eliminada' });
    } catch (error) {
        res.status(500).json({ error: 'Error al eliminar la cita' });
    }
});

//DIAGNOSIS

// LISTAR TODOS (con nombres)
app.get("/diagnosis", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        d.id,
        d.appointment_id,
        d.diagnosis,
        d.treatment,
        a.appointment_datetime,
        p.name AS patient_name,
        doc.name AS doctor_name
      FROM diagnosis d
      JOIN appointments a ON d.appointment_id = a.id
      JOIN patients p     ON a.patient_id = p.id
      JOIN doctors doc    ON a.doctor_id = doc.id
      ORDER BY d.id DESC
    `);
    return res.json(result.rows); // 👈 OJO: devolvemos array directo
  } catch (error) {
    console.error(error);
    res.status(500).json({error : 'error'});
  }
});

// OBTENER UNO (con nombres)
app.get("/diagnosis/:id", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        d.id,
        d.appointment_id,
        d.diagnosis,
        d.treatment,
        a.appointment_datetime,
        p.name AS patient_name,
        doc.name AS doctor_name
      FROM diagnosis d
      JOIN appointments a ON d.appointment_id = a.id
      JOIN patients p     ON a.patient_id = p.id
      JOIN doctors doc    ON a.doctor_id = doc.id
      WHERE d.id = $1
    `, [req.params.id]);
    return res.json(result.rows); // 👈 array (ej: [ {...} ])
  } catch (error) {
    console.error(error);
    res.status(500).json({error : 'error'});
  }
});

// CREAR
app.post('/diagnosis', async (req, res) => {
  const { appointment_id, diagnosis, treatment } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO diagnosis (appointment_id, diagnosis, treatment) VALUES ($1, $2, $3) RETURNING *',
      [appointment_id, diagnosis, treatment]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al crear el diagnóstico' });
  }
});

// ACTUALIZAR
app.put('/diagnosis/:id', async (req, res) => {
  const { id } = req.params;
  const { appointment_id, diagnosis, treatment } = req.body;
  try {
    const result = await pool.query(
      'UPDATE diagnosis SET appointment_id = $1, diagnosis = $2, treatment = $3 WHERE id = $4 RETURNING *',
      [appointment_id, diagnosis, treatment, id]
    );
    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Diagnóstico no encontrado' });
    }
    res.json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al actualizar el diagnóstico' });
  }
});

// ELIMINAR
app.delete('/diagnosis/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query('DELETE FROM diagnosis WHERE id = $1 RETURNING *', [id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Diagnóstico no encontrado' });
    res.json({ mensaje: 'Diagnóstico eliminado' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al eliminar el diagnóstico' });
  }
});

// ================== AUTH ==================
// POST /auth/register
app.post('/auth/register', async (req, res) => {
  try {
    const { nombres, apellidos, correo, contraseña } = req.body;

    if (!nombres || !apellidos || !correo || !contraseña) {
      return res.status(400).json({ error: 'Campos incompletos' });
    }

    const hashed = await bcrypt.hash(contraseña, 10);
    const insert = `
      INSERT INTO users (first_name, last_name, email, password_hash)
      VALUES ($1, $2, $3, $4) RETURNING id, first_name, last_name, email
    `;
    const result = await pool.query(insert, [nombres, apellidos, correo, hashed]);

    const user = result.rows[0];
    const token = jwt.sign({ uid: user.id, email: user.email }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });

    res.status(201).json({ user, token });
  } catch (err) {
    if (err.code === '23505') {
      return res.status(409).json({ error: 'El correo ya está registrado' });
    }
    console.error(err);
    res.status(500).json({ error: 'Error en registro' });
  }
});

// POST /auth/login
app.post('/auth/login', async (req, res) => {
  try {
    const { correo, contraseña } = req.body;
    if (!correo || !contraseña) {
      return res.status(400).json({ error: 'Campos incompletos' });
    }

    const q = 'SELECT id, first_name, last_name, email, password_hash FROM users WHERE email = $1 LIMIT 1';
    const r = await pool.query(q, [correo]);
    if (r.rows.length === 0) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    const user = r.rows[0];
    const ok = await bcrypt.compare(contraseña, user.password_hash);
    if (!ok) return res.status(401).json({ error: 'Credenciales inválidas' });

    const token = jwt.sign({ uid: user.id, email: user.email }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });

    // No regresamos el hash
    delete user.password_hash;
    res.json({ user, token });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error en login' });
  }
});

app.listen(3000, () => {
    console.log('Servidor corriendo en http://localhost:3000');
});